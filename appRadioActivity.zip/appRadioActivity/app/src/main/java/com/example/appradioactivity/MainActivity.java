package com.example.appradioactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    RadioButton catRadio;
    RadioButton dogRadio;
    RadioButton elephantRadio;
    RadioButton monkeyRadio;
    Button submitButton;
    RatingBar ratingBar;
    TextView catText;
    TextView dogText;
    TextView elephantText;
    TextView monkeyText;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        catRadio = findViewById(R.id.radioCat);
        dogRadio = findViewById(R.id.radioDog);
        elephantRadio = findViewById(R.id.radioElephant);
        monkeyRadio = findViewById(R.id.radioMonkey);

        submitButton = findViewById(R.id.submitButton);

        ratingBar = findViewById(R.id.ratingBar);

        catText = findViewById(R.id.textCat);
        dogText = findViewById(R.id.textDog);
        elephantText = findViewById(R.id.textElphant);
        monkeyText = findViewById(R.id.textMonkey);
        resultText = findViewById(R.id.textResult);

        catRadio.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    dogRadio.setChecked(false);
                    elephantRadio.setChecked(false);
                    monkeyRadio.setChecked(false);
                }
            }
        });

        dogRadio.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    catRadio.setChecked(false);
                    elephantRadio.setChecked(false);
                    monkeyRadio.setChecked(false);
                }
            }
        });

        elephantRadio.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    catRadio.setChecked(false);
                    dogRadio.setChecked(false);
                    monkeyRadio.setChecked(false);
                }
            }
        });

        monkeyRadio.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    catRadio.setChecked(false);
                    dogRadio.setChecked(false);
                    elephantRadio.setChecked(false);
                }
            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StringBuilder finalText = new StringBuilder();
                String text = "";
                float rating = ratingBar.getRating();

                if(catRadio.isChecked()){
                    text = catText.getText().toString();
                } else if (dogRadio.isChecked()) {
                    text = dogText.getText().toString();
                } else if (elephantRadio.isChecked()) {
                    text = elephantText.getText().toString();
                } else if (monkeyRadio.isChecked()) {
                    text = monkeyText.getText().toString();
                }

                if (!catRadio.isChecked() && !dogRadio.isChecked() && !elephantRadio.isChecked() && !monkeyRadio.isChecked()) {
                    finalText.append("Please choose an option");
                } else {
                    finalText.append("You rated ").append(text).append(" as ").append(rating).append(" hearts!");
                }

                resultText.setText(finalText);
            }
        });

    }
}